T = int(input())
list_a = list(input())
sum = 0
for i in range(len(list_a)) :
    sum += int(list_a[i])
print(sum)