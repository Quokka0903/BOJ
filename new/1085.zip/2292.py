N = int(input())
i = 1
six = 6
cnt = 1
while N > i :
    i += six
    six += 6
    cnt += 1

print(cnt)